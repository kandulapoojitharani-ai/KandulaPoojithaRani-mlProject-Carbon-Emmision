import os, json, joblib, pandas as pd
from flask import Flask, render_template, request, jsonify
BASE=os.path.dirname(os.path.abspath(__file__)); app=Flask(__name__)
DATA=os.path.join(BASE,'dataset','carbon_emissions.csv'); MODELS=os.path.join(BASE,'models'); PROC=os.path.join(BASE,'processed_data')
NUM=['electricity_kwh','natural_gas_m3','vehicle_km','flights_km','waste_kg','renewable_pct','avg_temp_c','occupancy','industrial_output','transport_load']; CAT=['sector','region']; FEATURES=NUM+CAT

def load():
 d=pd.read_csv(DATA); metrics=pd.read_csv(os.path.join(PROC,'model_metrics.csv')); meta=json.load(open(os.path.join(MODELS,'metadata.json'))); return d,metrics,meta
@app.route('/')
def index():
 d,m,meta=load(); return render_template('index.html',metrics=m.to_dict('records'),meta=meta,summary={'rows':len(d),'missing':int(d.isna().sum().sum()),'target_mean':round(d.carbon_kg_co2e.mean(),2),'target_max':round(d.carbon_kg_co2e.max(),2)},sectors=sorted(d.sector.dropna().unique()),regions=sorted(d.region.dropna().unique()))
@app.post('/predict')
def predict():
 data=request.get_json(force=True); row={k:data.get(k) for k in FEATURES};
 for k in NUM: row[k]=float(row[k]) if row[k] not in (None,'') else None
 results={}
 for name in ['linear_regression','gradient_boosting','random_forest']:
  path=os.path.join(MODELS,name+'.joblib')
  if os.path.exists(path): results[name]=round(float(joblib.load(path).predict(pd.DataFrame([row]))[0]),2)
 return jsonify({'predictions':results,'primary_model':'gradient_boosting'})
@app.get('/api/analytics')
def analytics():
 d,m,meta=load(); corr=d[NUM+['carbon_kg_co2e']].corr()['carbon_kg_co2e'].drop('carbon_kg_co2e').sort_values(ascending=False); fi=os.path.join(PROC,'feature_importance.csv'); imp=pd.read_csv(fi).to_dict('records') if os.path.exists(fi) else []
 return jsonify({'correlation':corr.to_dict(),'importance':imp,'metrics':m.to_dict('records')})
@app.get('/api/unsupervised')
def unsupervised():
 p=os.path.join(PROC,'unsupervised_results.json'); return jsonify(json.load(open(p)) if os.path.exists(p) else {})
@app.get('/api/evaluation')
def evaluation():
 p=os.path.join(PROC,'evaluation_results.json'); return jsonify(json.load(open(p)) if os.path.exists(p) else {})
@app.post('/api/retrain')
def retrain():
 from train import main; main(); from analyze import main as a; a(); from evaluate import main as e; e(); from unsupervised import main as u; u(); return jsonify({'status':'success','message':'Models retrained and artifacts refreshed.'})
if __name__=='__main__': app.run(debug=True)
